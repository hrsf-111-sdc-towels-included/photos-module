import React from 'react';
import ReactDOM from 'react-dom';
import Module from  './components/Module.jsx'

ReactDOM.render( 
  <Module />,
  document.getElementById('root')
);